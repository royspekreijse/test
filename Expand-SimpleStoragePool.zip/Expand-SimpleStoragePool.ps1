Function Get-StoragePoolDisk {
    $PhysicalDisks = Get-PhysicalDisk -CanPool $true
    $LogicalDisks = Get-Disk | Where-Object OperationalStatus -eq 'Offline'
    $EmptyDisks = @()
    ForEach ($LD in $LogicalDisks) {
        $EmptyDisks += $PhysicalDisks | Where-Object UniqueId -eq  $LD.UniqueID
    }
    $EmptyDisks
}

Function Expand-SimpleStoragePoolTier {
    <#
    .LINK
    https://charbelnemnom.com/2015/03/step-by-step-how-to-extend-and-resize-a-two-way-mirrored-storage-tiered-space-storagespaces-ws2012r2/
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $True)]
        [PSObject]$PhysicalDisk,
        [Parameter(Mandatory = $true)]
        [String]$StoragePoolFriendlyName,
        [Parameter(Mandatory = $true)]
        [ValidateSet('SSD', 'HDD')]
        [String]$Tier
    )
    
    Begin {}
    
    Process {
        foreach ($Disk in $PhysicalDisk) {
            $SPPool = Get-StoragePool -FriendlyName $StoragePoolFriendlyName
            $VD = $SPPool | Get-VirtualDisk
            $TierFriendlyName = ($VD | Get-StorageTier | Where-Object MediaType -eq $Tier).FriendlyName
            $SPPool | Add-PhysicalDisk -PhysicalDisks $Disk
            $Disk | Set-PhysicalDisk -MediaType $Tier

            $CurrentTierSize = (Get-StorageTier -FriendlyName $TierFriendlyName).Size
            #Get-StorageTierSupportedSize -FriendlyName $TierFriendlyName -ResiliencySettingName Simple |FT @{l="TierSizeMin(GB)";e={$_.TierSizeMin/1GB}},@{l="TierSizeMax(GB)";e={$_.TierSizeMax/1GB}},@{l="TierSizeDivisor(GB)";e={$_.TierSizeDivisor/1GB}}
            $MaxTierExpand = (Get-StorageTierSupportedSize -FriendlyName $TierFriendlyName -ResiliencySettingName Simple).TierSizeMax
            If ($MaxTierExpand -gt $Disk.Size) {
                $MaxExpand = $Disk.Size
            }
            Else {
                $MaxExpand = $MaxTierExpand
            }
            Resize-StorageTier -FriendlyName $TierFriendlyName -Size ($CurrentTierSize + $MaxExpand)
            $VD | Get-Disk | Update-Disk
        }
    }

    End {}
}

function Expand-SimpleStoragePool {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [String]$StoragePoolFriendlyName,
        [Parameter(Mandatory = $true)]
        [Int]$SizeGB,
        [Parameter(Mandatory = $true)]
        [ValidateSet('SSD', 'HDD')]
        [String]$Tier
    )

    $NewDisk = Get-StoragePoolDisk
    $Size = $SizeGB * 1GB
    $Disk = $NewDisk |Where-Object {$_.Size -gt ($Size - ($Size / 10)) -and $_.Size -lt ($Size + ($Size / 10))}
    Expand-SimpleStoragePoolTier -PhysicalDisk $Disk -StoragePoolFriendlyName $StoragePoolFriendlyName -Tier $Tier
}

