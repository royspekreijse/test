# Eerste version voor controleren van de tabellen. 

Deze module is gebouwd om het volgende uit te voeren. 
- Controle op nulwaarden in de tabellen.
- Controle op "Foute" waarden in de tabellen. 
- Controle op dubbelingen in de tabellen.
- Mailen van de resultaten naar bepaalde emailadressen. 
