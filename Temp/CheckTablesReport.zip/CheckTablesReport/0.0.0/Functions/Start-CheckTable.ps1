<#
.SYNOPSIS
    Checks table for null values and duplicates.
.DESCRIPTION
    Long description
.EXAMPLE
    Example of how to use this cmdlet
.EXAMPLE
    Another example of how to use this cmdlet
#>
function Start-CheckTable {
    [CmdletBinding()]
    [OutputType([int])]
    param(
        [Parameter(Mandatory = $true)]
        $TableParams,
        [Parameter(Mandatory = $true)]
        [System.IO.FileInfo]
        $LogFile,
        [Parameter(Mandatory = $true)]
        [PSObject]
        $Table
    )

    begin {
        Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Start Function"
        $Params = $TableParams
    }

    process {

        $columncheckvalues = @()
        if ($Params.ChecksColumnsForValues) {
            $totalrows = $table.Count
            $i = 0
            foreach ($tablerow in $Table) {
                Write-Progress -Activity "Collecting data of $($Params.TableName)" -status "Finding file $i of $totalrows" `
                    -percentComplete ($i / $totalrows * 100)
                $i++
                $resultarray = @()
                $j = 0
                foreach ($checkforvalue in $Params.ChecksColumnsForValues) {
                    $j++
                    $SplatParams = @{}
                    $SplatParams = $checkforvalue
                    $singleresult = Test-CompareValue @SplatParams -TableRow $tablerow
                    if ($singleresult["CheckSuccess"]) {
                        $resultarray += , $singleresult
                    }
                }
                if ($resultarray.Length -gt 0) {
                    $newrow = @{ RowKey = $tablerow.RowKey; Result = $resultarray; TableRow = $tablerow }
                    $columncheckvalues += , $newrow
                }
            }
        }
        $duplicatesvalues = @()
        if ($params.Duplicates) {
            foreach ($duplicate in $Params.Duplicates) {
                $SplatParams = @{}
                $SplatParams = $duplicate
                $addduplicates = (Find-Duplicates @SplatParams -Table $Table)
                if (($duplicate.Informatie) -and ($duplicate.InfoType)) {
                    foreach ($addduplicate in $addduplicates.Items) {
                        $aantalparams = [regex]::Matches($duplicate.Informatie, "(?<!\{)\{([0-9]+).*?\}(?!})").Count
                        $outputstring = "$($duplicate.InfoType):"
                        if ($aantalparams -eq 1) {
                            $outputstring += $duplicate.Informatie -f $addduplicate.Count
                            $responseitems += , "$($duplicate.Informatie -f $addduplicate.Count) `r`n"
                        }
                        if ($aantalparams -eq 2) {
                            $columnname = ($addduplicate | Get-Member -MemberType NoteProperty | Where-Object {$_.Name -ne "Count" }).Name
                            $columnvalue = $addduplicate.$columnname
                            $outputstring += $duplicate.Informatie -f $addduplicate.Count, $columnvalue
                            $responseitems += , "$($duplicate.Informatie -f $addduplicate.Count, $columnvalue)  `r`n"
                        }
                        if ($aantalparams -eq 3) {
                            $columnname = ($addduplicate | Get-Member -MemberType NoteProperty | Where-Object {$_.Name -ne "Count" }).Name
                            $columnvalue = $addduplicate.$columnname
                            $outputstring += $duplicate.Informatie -f $addduplicate.Count, $columnname, $columnvalue
                            $responseitems += , "$($duplicate.Informatie -f $addduplicate.Count, $columnname, $columnvalue)  `r`n"
                        }

                    }

                }
                $duplicatesvalues += , $addduplicates

            }
        }
        $output = @{
            ColumnChecks = $columncheckvalues;
            Duplicates   = $duplicatesvalues;
        }


        $jsonoutput = $output | ConvertTo-Json -Depth 10
        Add-Content $LogFile.FullName -Value $jsonoutput
        $jsonobj = $jsonoutput | ConvertFrom-Json
        $emailoutputitems = $jsonobj.ColumnChecks | Select-Object Result, RowKey -ExpandProperty Result | Select-Object Informatie, RowKey
        $resultchecks = @{}
        foreach ($emailoutputitem in $emailoutputitems) {
            foreach ($informatieitem in $emailoutputitem.Informatie) {
                if ($resultchecks.ContainsKey($informatieitem)) {
                    $currentAmmount = ($resultchecks.Get_Item($informatieitem)) + 1
                    $resultchecks.Set_Item($informatieitem, $currentAmmount)
                }
                else {
                    $resultchecks.Add($informatieitem, 1)
                }
            }
        }


        foreach ($resultcheck in $resultchecks.GetEnumerator()) {
            $aantalparams = [regex]::Matches($resultcheck.Name, "(?<!\{)\{([0-9]+).*?\}(?!})").Count
            if ($aantalparams -eq 1) {
                $responseitem = $resultcheck.Name -f $resultcheck.Value
            }
            else {
                $responseitem = $resultcheck.Name
            }

            $responseitems += , $responseitem
        }
        return $responseitems
    }

    end {
        Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): End Function"
    }
}