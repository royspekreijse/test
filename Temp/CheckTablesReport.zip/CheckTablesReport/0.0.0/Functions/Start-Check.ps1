Function Start-Check {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $false)]
        [String]$StorageAccountName = "csanalyticsdev",
        [Switch]$Force
    )


    #Set write-warning to better stand-out from verbose and debug info.
    $a = (Get-Host).PrivateData
    if ($a) {
        if ($a.WarningBackgroundColor) {
            $PreviousWarningBackgroundColor = $a.WarningBackgroundColor
            $PreviousWarningForegroundColor = $a.WarningForegroundColor
            $a.WarningBackgroundColor = "red"
            $a.WarningForegroundColor = "white"
        }
    }
    Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Starting"
    Write-Warning -Message "$($MyInvocation.MyCommand.Name): Publishing to StorageAccount $($StorageAccountName)"

    #[Reflection.Assembly]::LoadWithPartialName("System.Web.Script.Serialization")
    #$JSSerializer = [System.Web.Script.Serialization.JavaScriptSerializer]::new()
    Add-Type -AssemblyName System.Web.Extensions
    $JSSerializer = New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer

    $SplatSettings = @{}
    If ($Path) {$SplatSettings.Path = $Path}
    $AzureTableSettings = @()
    $AzureTableSettings = (Get-AzureTableSettings @SplatSettings).Where{$_.StorageAccountName -eq $StorageAccountName} #Not a true object, but array-like
    If (!($AzureTableSettings)) {
        Throw "No settings found for Storage Account name: $($StorageAccountName). Cannot continue!"
    }

    $SplatSettings = @{
        StorageAccountName = $AzureTableSettings.StorageAccountName
        StorageAccountKey  = $AzureTableSettings.StorageKey
    }

    #$Ctx = New-AzureStorageContext @SplatSettings

    $SplatSettings = @{
        "Column"       = "Status"
        "DefaultValue" = "Active"
    }
    if (-not $PSScriptRoot) {
        $scriptlocation = (Get-Location).Path
    }
    else {
        $scriptlocation = $PSScriptRoot
    }


    #Force reload machinestable
    $SplatSettings = @{
        #MachinesTable      = $AzureTableSettings.MachinesTable
        StorageAccountName = $AzureTableSettings.StorageAccountName
        StorageKey         = $AzureTableSettings.StorageKey
        Tables             = $AzureTableSettings.Tables
    }
    #$SplatSettings
    #$SplatSettings.Tables
    Get-AzureData @SplatSettings #-Force


    <#
    $Checks = @(
        @{
            LogFileName = "$env:TEMP\Log\CustomersLog.json";
            JSON        = Get-Content $scriptlocation\..\Settings\CheckCustomers.json;
            TableItems  = $Global:CustomersTable;
        },
        @{
            LogFileName = "$env:TEMP\Log\MachinesLog.json";
            JSON        = Get-Content $scriptlocation\..\Settings\CheckMachines.json;
            TableItems  = $Global:MachinesTable;
        },
        @{
            LogFileName = "$env:TEMP\Log\MachinesStorageMetricsLog.json";
            JSON        = Get-Content $scriptlocation\..\Settings\CheckMachinesStorageMetrics.json;
            TableItems  = $Global:MachineStorageMetricsTable;
        },
        @{
            LogFileName = "$env:TEMP\Log\MachineReportLog.json";
            JSON        = Get-Content $scriptlocation\..\Settings\CheckMachinesReport.json;
            TableItems  = $Global:MachineReportTable;
        },
        @{
            LogFileName = "$env:TEMP\Log\IaasMachineStorageMetricsLog.json";
            JSON        = Get-Content $scriptlocation\..\Settings\CheckIaasMachineStorageMetrics.json;
            TableItems  = $Global:IaaSMachineStorageMetricsTable;
        }
    )
    ,
        @{
            JSON = Get-Content $scriptlocation\..\Settings\CheckIaasMachineStorageMetrics.json;
        },
        @{
            JSON = Get-Content $scriptlocation\..\Settings\CheckMachinesStorageMetrics.json;
        }
    #>
    $Checks = @(
        @{
            JSON = Get-Content $scriptlocation\..\Settings\CheckCustomers.json;
        },
        @{
            JSON = Get-Content $scriptlocation\..\Settings\CheckMachines.json;
        },
        @{
            JSON = Get-Content $scriptlocation\..\Settings\CheckMachinesReport.json;
        }
    )

    #region Machines
    $files = @()
    [array]$mailbodyLines = @()
    foreach ($Check in $Checks) {
        $settingsfile = $JSSerializer.Deserialize($Check.JSON , 'Hashtable')
        $Logfile = New-Item "$($env:TEMP)\Log\$($settingsfile.LogFile)" -ItemType File -Force
        $Table = Get-Variable -Name $settingsfile.TableItems -Scope GLobal -ErrorAction SilentlyContinue
        Write-Output "Start writing to file $($settingsfile.LogFile)"
        $checkresult = @()
        If ($Table) {
            $TableItems = $Table.Value
            $checkresult = Start-CheckTable  -TableParams $settingsfile -LogFile $Logfile -Table $TableItems
            $emptytable = $false;
        }
        else {
            Write-Output "No items for $($Check.LogFileName)"
            $content = @{ LogFileName = $Logfile.Name; Content = "Table is Empty" } | ConvertTo-Json
            Add-Content $LogFile.FullName -Value $content
            $emptytable = $true;
        }
        $mailbodyLines += , @{
            Name         = $settingsfile.TableName;
            LogFile      = $settingsfile.LogFile
            CheckResults = $checkresult
            EmptyTable   = $emptytable
        }

        $files += , $Logfile.FullName
    }
    $Global:mailbodyLines = $mailbodyLines
    $htmlmailbodyLines = ""
    foreach ($mailbodyLine in $mailbodyLines) {
        $htmlmailbodyLines += "<h3>Controle voor tabel: $($mailbodyLine.Name)</h3>"
        if ($mailbodyLine.CheckResults.Length -gt 0) {
            foreach ($checkresult in $mailbodyLine.CheckResults) {
                $htmlmailbodyLines += "<p>$($checkresult)</p>"
            }
            $htmlmailbodyLines += "<p>Voor detailinformatie check de bijlage: $($mailbodyLine.LogFile)</p>"
        }
        else {
            if ($mailbodyLine.EmptyTable) {
                $htmlmailbodyLines += "<p>Tabel is leeg</p>"
            }
            else {
                $htmlmailbodyLines += "<p>Geen bijzonderheden</p>"
            }

        }
        $htmlmailbodyLines += "<hr>"
    }

    $tablestatistics = New-TableStatistics -Machines $MachinesTable -MachineReport $MachineReportTable

    $htmlmailbodyLines += "<h3>Controle voor tabel: $($tablestatistics.Header)</h3>"
    $htmlmailbodyLines += "<p>"
    foreach ($line in $tablestatistics.Info.Split("`n")) {
        $htmlmailbodyLines += "$($line)<br>"
    }
    $htmlmailbodyLines += "</p>"
    $files += $tablestatistics.Files
    Start-SendMail -Name "CheckTableSettings" -Subject "Automatische controle rapport" -Body $htmlmailbodyLines -Attachments $files
    foreach ($file in $files) {
        Remove-Item -Path $file
    }
    if ($a) {
        if ($a.WarningBackgroundColor) {
            $a.WarningBackgroundColor = $PreviousWarningBackgroundColor
            $a.WarningForegroundColor = $PreviousWarningForegroundColor
        }
    }
}