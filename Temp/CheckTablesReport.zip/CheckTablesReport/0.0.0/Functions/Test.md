
# Hello World
```Powershell
$code = ""
```
Dit is geen code
```Powershell
$code
```
