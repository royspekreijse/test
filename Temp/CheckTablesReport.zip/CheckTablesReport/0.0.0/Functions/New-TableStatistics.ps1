function New-TableStatistics {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [PSObject]$Machines,
        [Parameter(Mandatory = $true)]
        [PSObject]$MachineReport,
        [int16]$NumberOfPreviousDays = 7
    )

    #Set write-warning to better stand-out from verbose and debug info.
    $a = (Get-Host).PrivateData
    If ($a) {
        #Not every PS host has this capability
        $PreviousWarningBackgroundColor = $a.WarningBackgroundColor
        $PreviousWarningForegroundColor = $a.WarningForegroundColor
        $PreviousVerboseForegroundColor = $a.VerboseForegroundColor
        $a.WarningBackgroundColor = "red"
        $a.WarningForegroundColor = "white"
        $a.VerboseForegroundColor = 'cyan'
    }
    Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Starting"

    $DateString = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd")
    $Header = "CloudSuite Reporting - TableStatistics created on $($DateString)"
    $Files = @()

    $Info = [String]::Empty

    #Machines
    $Info += "`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $Info += "Machines table`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $ActiveMachines = $Machines | Where-Object {$_.Status -eq 'Active'}
    $Info += "Machine table contains total of $($Machines.Count) machines`n"
    $IaaSMachines = $ActiveMachines | Where-Object {$_.SubscriptionID -ne '10000000-0000-0000-0000-000000000001' -and $_.SubscriptionID -ne $null -and $_.SubscriptionID -ne '' }
    $Info += "Machine table contains total of $($IaaSMachines.Count) active machines registered on ITON IaaS`n"
    $MultipleMAC = @()
    $Grouped = $ActiveMachines | Group-Object MAC
    foreach ($Group in $Grouped) {
        If ($Group.count -gt 1) {
            foreach ($Item in $Group.Group) {
                $MultipleMAC += $Item
            }
        }
        #$Result += $Group.Group[-1] #Just post last upload
    }
    If ($MultipleMAC) {
        $Info += "WARNING: Multiple MAC usage detected. $($Grouped.Count) MAC addresses shared amongst $($Grouped.Group.Count) active machines. Differences in some counts might occur`n"
        $FileName = "$($env:TEMP)\Machines-MultipleMAC.json"
        $MultipleMAC | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }
    $NoIaaSMachines = $ActiveMachines | Where-Object {$_.SubscriptionID -eq '10000000-0000-0000-0000-000000000001' -or $_.SubscriptionID -eq $null -or $_.SubscriptionID -eq '' }
    If ($NoIaaSMachines) {
        $Info += "WARNING: Machine table contains $($NoIaaSMachines.Count) active machine(s) which are not registered in any IaaS`n"
        $FileName = "$($env:TEMP)\Machines-NoIaaSMachines.json"
        $NoIaaSMachines | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }
    $WindowsMachines = $ActiveMachines | Where-Object vmOSType -eq "Windows"
    $Info += "Machine table contains total of $($WindowsMachines.Count) Windows machines`n"
    $NoWindowsMachines = $ActiveMachines | Where-Object vmOSType -ne "Windows"
    If ($NoWindowsMachines) {
        $Info += "WARNING: Machine table contains $($NoWindowsMachines.Count) machine(s) which are not Windows-based`n"
        $FileName = "$($env:TEMP)\Machines-NoWindowsMachines.json"
        $NoWindowsMachines | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }
    $Windows2008Machines = $ActiveMachines | Where-Object vmOSName -like "*2008*"
    If ($Windows2008Machines) {
        $Info += "WARNING: Machine table contains total of $($Windows2008Machines.Count) Windows 2008 platform machines`n"
        $FileName = "$($env:TEMP)\Machines-Windows2008.json"
        $Windows2008Machines | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }
    $DownMachines = $ActiveMachines | Where-Object vmStatus -eq "PowerOff"
    If ($DownMachines) {
        $Info += "WARNING: Machine table contains total of $($DownMachines.Count) machines which are turned off`n"
        $FileName = "$($env:TEMP)\Machines-Down.json"
        $DownMachines | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }

    #MachineReport general
    $Info += "`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $Info += "MachineReport table - general`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $MachineReportLatest = @()
    $MachineReportGrouped = $MachineReport | Group-Object MAC
    Foreach ($MRG in $MachineReportGrouped) {
        $LatestUploadDate = ($MRG.Group | measure-object -property CreatedTimeStamp -Maximum).Maximum
        $MachineReportLatest += $MRG.Group | Where-Object CreatedTimeStamp -eq $LatestUploadDate
    }

    #Just export complete report for customer reference checking (Service management)
    If ($MachineReportLatest) {
        $FileName = "$($env:TEMP)\MachineReport-Latest.csv"
        $MachineReportLatest | Export-Csv -Path $FileName -Delimiter ',' -Force
        $Files += $FileName
    }

    $MachineReportLastDay = $MachineReportLatest | Where-Object {$_.CreatedTimestamp -ge (Get-Date).AddDays( - 1)}
    $Info += "MachineReport table contains reports for $($MachineReportGrouped.Count) machines`n"
    $Info += "MachineReports created for $($MachineReportLastDay.Count) machines within last 24 hours`n"

    #Just get last result, if there have been multiple uploads (testing or other reason)
    $Result = @()
    $MultipleMAC = @()
    $Grouped = $MachineReportLastDay | Group-object MAC # Detect multiple uploads within timeframe
    foreach ($Group in $Grouped) {
        If ($Group.count -gt 1) {
            foreach ($Item in $Group.Group) {
                $MultipleMAC += $Item
            }
        }
        $Result += $Group.Group[-1] #Just post last upload
    }
    $MachineReportDay = $Result
    If ($MultipleMAC) {
        $Info += "WARNING: Multiple MAC usage detected. $($Grouped.Count) MAC addresses shared amongst $($Grouped.Group.Count) reported machines. Using only one sample. Differences in some counts might occur`n"
        $FileName = "$($env:TEMP)\MachineReport-MultipleMAC.json"
        $MultipleMAC | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }
    $CompareResult = Compare-Object $IaaSMachines $MachineReportDay -Property vmId
    $MissingIaaSMachines = @()
    foreach ($Item in $CompareResult) {
        If ($Item.SideIndicator -eq '<=') {
            $MissingIaaSMachines += $IaaSMachines |Where-Object -property vmId -eq $Item.vmId
        }
    }
    If ($MissingIaaSMachines) {
        $Info += "WARNING: Missing $($MissingIaaSMachines.Count) machines in MachineReport table from ITON IaaS`n"
        $FileName = "$($env:TEMP)\MachineReport-MissingIaaSMachines.json"
        $MissingIaaSMachines | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }

    #MachineReport bruto values
    $Info += "`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $Info += "MachineReport table - bruto values`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $MachineReportBruto = @()
    For ($i = 0; $i -lt $NumberOfPreviousDays; $i++) {
        #Last day is defined as 'error' day; total count back is more then $NumberOfPreviousDays then
        $DateString = (Get-Date).AddDays( - $i).ToUniversalTime().ToString("yyyy-MM-dd")
        $MachineReportCurrent = $MachineReportDay| Where-Object {$_.IaaSMetricsDate -eq $DateString}
        If ($MachineReportCurrent) {
            $Info += "$($MachineReportCurrent.Count) machines reported bruto values, created on $($DateString)`n"
            $MachineReportBruto += $MachineReportCurrent
        }
    }
    If ($MachineReportBruto.Count -eq $MachineReportDay.Count) {
        $Info += "All machines reported bruto values`n"
    }
    Else {
        $MachineReportNoBrutoValues = @()
        #$CompareResult = Compare-Object $IaaSMachines $MachineReportDay -Property vmId
        #foreach ($Item in $CompareResult) {
        $Info += "WARNING: $($MachineReportDay.Count - $MachineReportBruto.Count) machines have no or older bruto values`n"
        Try {
            $CompareResult = Compare-Object $MachineReportBruto $MachineReportDay -Property vmId -ErrorAction Stop
            foreach ($Item in $CompareResult) {
                If ($Item.SideIndicator -eq '=>') {
                    $MachineReportNoBrutoValues += $IaaSMachines |Where-Object -property vmId -eq $Item.vmId
                }
            }
        }
        Catch {
            $MachineReportNoBrutoValues = $MachineReportDay
        }
        $FileName = "$($env:TEMP)\MachineReport-NoBrutoValues.json"
        $MachineReportNoBrutoValues | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
        #}
    }

    #MachineReport netto values
    $Info += "`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $Info += "MachineReport table - netto values`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $MachineReportWindows = @()
    Foreach ($WM in $WindowsMachines) {
        $MachineReportWindows += $MachineReportDay | Where-Object {$_.MAC -eq $WM.MAC -and $_.OSName -notlike "*2008*"}
    }
    $Info += "Analyzing netto values for $($MachineReportWindows.Count) Windows >= 2012 machines ...`n"
    $MachineReportStatusActive = @()
    $MachineReportStatusOther = @()
    Foreach ($WM in $MachineReportWindows) {
        $MachineReportStatusActive += $WM | Where-Object Status -eq "Running"
        $MachineReportStatusOther += $WM | Where-Object Status -ne "Running"
    }
    If ($MachineReportStatusOther) {
        $Info += "WARNING: $($MachineReportStatusActive.Count) machines in MachineReport table reported running. Dismissing $($MachineReportStatusOther.Count) machines.`n"
        $FileName = "$($env:TEMP)\MachineReport-StatusOther.json"
        $MachineReportStatusOther | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }
    $MachineReportNetto = @()
    For ($i = 0; $i -lt $NumberOfPreviousDays; $i++) {
        #Last day is defined as 'error' day; total count back is more then $NumberOfPreviousDays then
        $DateString = (Get-Date).AddDays( - $i).ToUniversalTime().ToString("yyyy-MM-dd")
        $MachineReportCurrent = $MachineReportStatusActive| Where-Object {$_.MachineMetricsDate -eq $DateString}
        $MachineReportCurrent = $MachineReportCurrent | Where-Object NettoOSSize -gt 0 # There must also be values!
        If ($MachineReportCurrent ) {
            $Info += "$($MachineReportCurrent.Count) machines reported netto values, created on $($DateString)`n"
            $MachineReportNetto += $MachineReportCurrent
        }
    }
    If ($MachineReportNetto.Count -eq $MachineReportStatusActive.Count) {
        $Info += "All active machines reported netto values`n"
    }
    Else {
        $MachineReportNoNettoValues = @()
        $Info += "WARNING: $($MachineReportStatusActive.Count - $MachineReportNetto.Count) active machines have no or older netto values`n"
        Try {
            $CompareResult = Compare-Object $MachineReportNetto $MachineReportStatusActive -Property vmId -ErrorAction Stop
            foreach ($Item in $CompareResult) {
                If ($Item.SideIndicator -eq '=>') {
                    $MachineReportNoNettoValues += $IaaSMachines |Where-Object -property vmId -eq $Item.vmId
                }
            }
        }
        Catch {
            $MachineReportNoNettoValues = $MachineReportStatusActive
        }

        $FileName = "$($env:TEMP)\MachineReport-NoNettoValues.json"
        $MachineReportNoNettoValues | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }

    If ($MachineReportNoNettoValues) {
        $Exceptions = [PSCustomObject]@{
            Environments = "bmb-*", "dm2016-*", "tn2016-*", "joey66-*", "ior-*", "rla-*", "swa-*", "yd-*", "ydenticdemo-*", "ixus-*", "wrksp365-*"
            Machines     = "cau01", "ns1", "bck7", "prtg1", "kaseyatest01", "abv-testvm1", "ammd-rdshx", "agf-adds1", "agf-adds2", "iton-dpm-test", "gratst-srv", "frans-mgt1", "gra-mgt02", "gra-rca01"
        }

        $c = @()
        Foreach ($vm in $MachineReportNoNettoValues) {
            $AddItem = $true
            Foreach ($Exception in $Exceptions.Environments) {
                If ( $vm.vmname -like $Exception) { $AddItem = $false }
            }
            Foreach ($Exception in $Exceptions.Machines) {
                If ( $vm.vmname -like $Exception) { $AddItem = $false }
            }
            If ( $AddItem -eq $true ) {
                $c += $vm
            }
        }

        If ($c) {
            $Info += "WARNING: $($c.Count) machines without netto values remain, after removing Exceptions`n"
            $FileName = "$($env:TEMP)\MachineReport-NoNettoValuesRemaining.json"
            $c | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
            $Files += $FileName
        }
    }


    return [PSCustomObject] @{
        Header = $Header
        Info   = $Info
        Files  = $Files
    }

    If ($a) {
        $a.WarningBackgroundColor = $PreviousWarningBackgroundColor
        $a.WarningForegroundColor = $PreviousWarningForegroundColor
        $a.VerboseForegroundColor = $PreviousVerboseForegroundColor
    }
}