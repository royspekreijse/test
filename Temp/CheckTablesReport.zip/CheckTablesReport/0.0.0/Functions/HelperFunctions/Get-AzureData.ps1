Function Get-AzureData {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)][String]$CustomersTable,
        [Parameter(Mandatory = $false)][String]$MachinesTable,
        [Parameter(Mandatory = $false)][String]$MachineStorageMetricsTable,
        [Parameter(Mandatory = $false)][String]$IaaSMachineStorageMetricsTable,
        [Parameter(Mandatory = $false)][String]$MachineReportTable,
        [Parameter(Mandatory = $false)][PSCustomObject]$Tables,
        [Parameter(Mandatory = $true)]
        [String]$StorageAccountName,
        [Parameter(Mandatory = $true)]
        [String]$StorageKey,
        #Load last 7 days of gathered data
        [int16]$NumberOfPreviousDays = 7,
        [switch]$Force
    )

    Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Starting"
    if ($CustomersTable) {
        Write-Warning -Message "`$CustomersTable is deprecated use `$Tables as input parameter"
    }
    if ($MachinesTable) {
        Write-Warning -Message "`$MachinesTable is deprecated use `$Tables as input parameter"
    }
    if ($IaaSMachineStorageMetricsTable) {
        Write-Warning -Message "`$IaaSMachineStorageMetricsTable is deprecated use `$Tables as input parameter"
    }
    if ($MachineStorageMetricsTable) {
        Write-Warning -Message "`$MachineStorageMetricsTable is deprecated use `$Tables as input parameter"
    }


    #Define the OData filterstring for filtering the wanted timespan of data to retrieve

    $SplatSettings = @{
        StorageAccountName = $StorageAccountName
        StorageAccountKey  = $StorageKey
    }

    $Ctx = New-AzureStorageContext @SplatSettings
    If ($Tables) {
        foreach ($table in $tables) {
            $globalexists = Get-Variable -Scope Global | Where-Object {$_.Name -eq $table.InternalName}
            if ($Force -or !$globalexists) {
                #Load all Customers
                Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Getting $($Table) data"
                $TableObj = Get-AzureStorageTable -Name $Table.Name -Context $Ctx
                if ($Table.FilterPreviousDays) {
                    $FilterStringPreviousDays = [string]::Format( "Timestamp ge datetime'{0}'", (Get-Date).AddDays( - $Table.FilterPreviousDays).ToUniversalTime().ToString("yyyy-MM-ddT00:00:00.000Z"))
                    $TableOutput = Get-AzureStorageTableRowByCustomFilter -table $TableObj -customFilter $FilterStringPreviousDays
                }
                else {
                    $TableOutput = Get-AzureStorageTableRowAll -table $TableObj
                }
                foreach ($rowitem in $TableOutput) {
                    if ($rowitem.CreatedTimestamp) {
                        $rowitem | Add-Member -MemberType NoteProperty -Name "Datum" -Value $rowitem.CreatedTimestamp.ToString("yyyyMMdd")
                    }
                }
                Set-Variable -Name $Table.InternalName -Value $TableOutput -Scope Global
            }
            else {
                Write-Warning -Message ($MyInvocation.MyCommand.Name + ": Using existing values in global variable $($Table). Use -Force parameter to force a refresh")
            }
        }
    }
    <#
    If ($CustomersTable) {
        If (($Customers) -and (!($Force))) {
            Write-Warning -Message ($MyInvocation.MyCommand.Name + ': Using existing values in global variable $Customers. Use -Force parameter to force a refresh')
        }
        Else {
            #Load all Customers
            Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Getting $($CustomersTable) data"
            $CustomersTableObj = Get-AzureStorageTable -Name $CustomersTable -Context $Ctx
            $global:Customers = Get-AzureStorageTableRowAll -table $CustomersTableObj
        }
    }

    If ($MachinesTable) {
        If (($Machines) -and (!($Force))) {
            Write-Warning -Message ($MyInvocation.MyCommand.Name + ': Using existing values in global variable $Machines. Use -Force parameter to force a refresh')
        }
        Else {
            #Load all Machines
            Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Getting $($MachinesTable) data"
            $MachinesTableObj = Get-AzureStorageTable -Name $MachinesTable -Context $Ctx
            $global:Machines = Get-AzureStorageTableRowAll -table $MachinesTableObj
        }
    }

    If ($MachineStorageMetricsTable) {
        If (($MachineStorageMetrics) -and (!($Force))) {
            Write-Warning -Message ($MyInvocation.MyCommand.Name + ': Using existing values in global variable $MachineStorageMetrics. Use -Force parameter to force a refresh')
        }
        Else {
            #Load filtered MachineMetrics
            Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Getting $($MachineStorageMetricsTable) data"
            $MachineStorageMetricsTableObj = Get-AzureStorageTable -Name $MachineStorageMetricsTable -Context $Ctx
            $global:MachineStorageMetrics = Get-AzureStorageTableRowByCustomFilter -table $MachineStorageMetricsTableObj -customFilter $FilterStringPreviousDays

        }
    }

    If ($IaaSMachineStorageMetricsTable) {
        If (($IaaSMachineStorageMetrics) -and (!($Force))) {
            Write-Warning -Message ($MyInvocation.MyCommand.Name + ': Using existing values in global variable $IaaSMachineStorageMetrics. Use -Force parameter to force a refresh')
        }
        Else {
            #Load filtered IaaSMachineMetrics
            Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Getting $($IaaSMachineStorageMetricsTable) data"
            $IaaSMachineStorageMetricsTableObj = Get-AzureStorageTable -Name $IaaSMachineStorageMetricsTable -Context $Ctx
            $global:IaaSMachineStorageMetrics = Get-AzureStorageTableRowByCustomFilter -table $IaaSMachineStorageMetricsTableObj -customFilter $FilterStringPreviousDays
        }
    }

    If ($MachineReportTable) {
        If (($MachineReport) -and (!($Force))) {
            Write-Warning -Message ($MyInvocation.MyCommand.Name + ': Using existing values in global variable $MachineReport. Use -Force parameter to force a refresh')
        }
        Else {
            #Load all Customers
            Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Getting $($MachineReportTable) data"
            $MachineReportTableObj = Get-AzureStorageTable -Name $MachineReportTable -Context $Ctx
            $global:MachineReport = Get-AzureStorageTableRowAll -table $MachineReportTableObj
        }
    }
    #>
}