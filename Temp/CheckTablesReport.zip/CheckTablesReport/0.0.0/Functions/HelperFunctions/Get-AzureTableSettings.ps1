Function Get-AzureTableSettings {
    [CmdletBinding()]
    param(
        [ValidateScript( {Test-Path $_ -IsValid})]
        [String]$Path = "$PSScriptRoot\..\..\Settings\AzureTable.json",
        [ValidateScript( {Get-CIMSession -Name $_.Name })]
        [PSObject]$CimSession
    )

    If ($CimSession) {
        $SplatCimSession = @{
            CimSession = $CimSession
        }
        If ($CimSession.ComputerName -eq '.') {$ComputerName = $env:COMPUTERNAME} Else {$ComputerName = $CimSession.ComputerName}
        $SplatComputerName = @{
            ComputerName = $ComputerName
        }
    }
    Else {
        $SplatCimSession = @{}
        $SplatComputerName = @{
            ComputerName = $env:COMPUTERNAME
        }
    }

    Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Starting"

    #Get the settings for reporting
    If ($SplatComputerName.ComputerName -eq $env:COMPUTERNAME) {

        #[Reflection.Assembly]::LoadWithPartialName("System.Web.Script.Serialization")
        $JSSerializer = [System.Web.Script.Serialization.JavaScriptSerializer]::new()
        $json = Get-Content -Path $Path -Raw | ConvertFrom-Json
        $JSSerializer.Deserialize($json, 'Hashtable')
        return $json
    }
    Else {
        Invoke-Command -Session @SplatComputerName -ScriptBlock {Get-Content -Path $USING:Path | ConvertFrom-Json}
    }
}