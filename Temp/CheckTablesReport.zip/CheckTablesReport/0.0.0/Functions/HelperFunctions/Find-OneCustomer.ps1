<#
.SYNOPSIS
    Finds a customer in an array and returns 1 or nothing
.DESCRIPTION
    Finds a customer in an array and based on parameters looks if it exists.
    If it exists it returns the customer and stops looking for the next one.
.EXAMPLE
    Example of how to use this cmdlet
    Find-Customer -CustomerList $Customers -ShortName "yd"
.EXAMPLE
    Another example of how to use this cmdlet
    Find-Customer -CustomerList $Customers -ShortName "yd"

#>
function Find-OneCustomer {
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory = $false)]
        [string]
        $KvK,
        [Parameter(Mandatory = $false)]
        [string]
        $ShortName,
        [Parameter(Mandatory = $false)]
        [string]
        $SubscriptionID,
        [Parameter(Mandatory = $false)]
        [string]
        $ID,
        [Parameter(Mandatory = $false)]
        [string]
        $RowKey,
        [Parameter(Mandatory = $true)]
        [Array]
        $CustomerList
    )

    begin {
        $checks = $PSBoundParameters
    }

    process {
        foreach ($customer in $CustomerList) {
            $testbool = $false
            if ($checks.Count -gt 1) {
                $testbool = $true
                foreach ($check in $checks.GetEnumerator()) {
                    If ($check.Key -ne "CustomerList") {
                        if ($customer.($check.Key)) {
                            if ($customer.($check.Key) -ne $check.Value) {
                                $testbool = $false
                            }
                        }
                        else {
                            $testbool = $false;
                        }

                    }
                }
            }
            if ($testbool) {
                return $customer
            }
        }
        return $null
    }

    end {
    }
}