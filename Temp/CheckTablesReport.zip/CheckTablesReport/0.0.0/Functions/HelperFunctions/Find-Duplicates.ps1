<#
.SYNOPSIS
    Short description
.DESCRIPTION
    Long description
.EXAMPLE
    Example of how to use this cmdlet
.EXAMPLE
    Another example of how to use this cmdlet
#>
function Find-Duplicates {
    [CmdletBinding()]
    [OutputType([int])]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]
        $Table,
        [Parameter(Mandatory = $true)]
        [string[]]
        $GroupColumns,
        [Parameter(Mandatory = $true)]
        [string]
        $CountColumn,
        [Parameter(Mandatory = $false)]
        [ValidateSet("eq", "ge", "le", "gt", "lt")]
        [string]
        $CompareType = "ge",
        [Parameter(Mandatory = $false)]
        [int]
        $CountNumber = 2,
        [Parameter(Mandatory = $false)]
        [string]
        $Name = "Unknown",
        [Parameter(Mandatory = $false)]
        [string]
        $Informatie,
        [Parameter(Mandatory = $false)]
        [string]
        $InfoType
    )

    begin {
        Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Starting"
        foreach ($PSBoundParameter in $PSBoundParameters.GetEnumerator()) {
            Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): [Parameter]: $($PSBoundParameter.Key) : [Value]: $($PSBoundParameter.Value)"
        }
    }

    process {

        [string[]]$OtherGroupColumns = @()
        [string[]]$OtherGroupColumnsWithCount = @()
        $OtherGroupColumns = $GroupColumns | Where-Object {$_ -ne $CountColumn}
        $GroupedDuplicates = $Table | Sort-Object $GroupColumns -Unique | Select-Object $GroupColumns | Group-Object $OtherGroupColumns

        $OtherGroupColumnsWithCount = $OtherGroupColumns
        $OtherGroupColumnsWithCount += "Count"
        $Duplicates = $GroupedDuplicates | Select-Object Count, @{Name = "Group" ; Expression = { $_.Group[0] }}
        $Duplicates = $Duplicates | Select-Object -Property "Count" -ExpandProperty "Group"
        $Duplicates = $Duplicates | Select-Object -Property $OtherGroupColumnsWithCount
        $Duplicates = $Duplicates | Sort-Object -Property $OtherGroupColumnsWithCount
        switch ($CompareType) {
            "eq" {
                $retval = $Duplicates | Where-Object {$_.Count -eq $CountNumber}
            }
            "ge" {
                $retval = $Duplicates | Where-Object {$_.Count -ge $CountNumber}
            }
            "le" {
                $retval = $Duplicates | Where-Object {$_.Count -le $CountNumber}
            }
            "gt" {
                $retval = $Duplicates | Where-Object {$_.Count -gt $CountNumber}
            }
            "lt" {
                $retval = $Duplicates | Where-Object {$_.Count -lt $CountNumber}
            }
            Default {}
        }
        return @{
            Name  = $Name;
            Items = $retval;
        }
    }

    end {
    }
}
