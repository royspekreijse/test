<#
.SYNOPSIS
    Short description
.DESCRIPTION
    Long description
.EXAMPLE
    Example of how to use this cmdlet
.EXAMPLE
    Another example of how to use this cmdlet
#>
function Select-MaxValue {
    [CmdletBinding()]
    [OutputType([int])]
    param(
        [Parameter(Mandatory = $true)]
        [string[]]
        $GroupProperties,
        [Parameter(Mandatory = $true)]
        [string]
        $MaxProperty,
        [Parameter(Mandatory = $true)]
        [array]
        $array
    )

    begin {
        Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Description"
        $countitems = 0
    }

    process {
        $returnarray = @()
        $GroupedArray = $array | Group-Object -Property $GroupProperties

        foreach ($groupitem in $GroupedArray) {
            $additem = ($groupitem.Group | Sort-Object -Property $MaxProperty)[-1]
            $returnarray += , $additem
            $countitems += 1
        }

        return $returnarray
    }

    end {

    }
}
