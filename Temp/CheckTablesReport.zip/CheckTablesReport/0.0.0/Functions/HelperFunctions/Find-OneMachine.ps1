<#
.SYNOPSIS
    Short description
.DESCRIPTION
    Long description
.EXAMPLE
    Example of how to use this cmdlet
.EXAMPLE
    Another example of how to use this cmdlet
#>
function Find-OneMachine {
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory = $false)]
        [string]
        $RowKey,
        [Parameter(Mandatory = $false)]
        [string]
        $MAC,
        [Parameter(Mandatory = $false)]
        [string]
        $BIOS,
        [Parameter(Mandatory = $false)]
        [string]
        $SubscriptionID,
        [Parameter(Mandatory = $false)]
        [string]
        $vmId,
        [Parameter(Mandatory = $false)]
        [string]
        $vmName,
        [Parameter(Mandatory = $false)]
        [string]
        $vmStatus,
        [Parameter(Mandatory = $false)]
        [string]
        $vmHWProfile,
        [Parameter(Mandatory = $false)]
        [double]
        $vmCPUCount,
        [Parameter(Mandatory = $false)]
        [double]
        $vmGeneration,
        [Parameter(Mandatory = $true)]
        [Array]
        $MachinesList
    )

    begin {
        $checks = $PSBoundParameters
        $retval = @{Machines = @(); Ammount = 0}
    }

    process {
        foreach ($machine in $MachinesList) {
            if ($checks.Count -gt 1) {
                $testbool = $true
                foreach ($check in $checks.GetEnumerator()) {
                    If ($check.Key -ne "MachinesList") {
                        if ($machine.($check.Key)) {
                            if ($machine.($check.Key) -ne $check.Value) {
                                $testbool = $false
                            }
                        }
                        else {
                            $testbool = $false
                        }
                    }
                }
                if ($testbool) {
                    $retval.Machines += $machine
                    $retval.Ammount += 1
                }
            }
        }
        #return $null
    }

    end {
        return $retval
    }
}