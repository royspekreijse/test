<#
.SYNOPSIS
    Short description
.DESCRIPTION
    Long description
.EXAMPLE
    Example of how to use this cmdlet
.EXAMPLE
    Another example of how to use this cmdlet
#>
function Test-CompareValue {
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory = $true)]
        [PSObject]
        $TableRow,
        [Parameter(Mandatory = $false)]
        [string]
        $ColumnName,
        [Parameter(Mandatory = $true)]
        $Waarde,
        [Parameter(Mandatory = $true)]
        [string]
        $Operator,
        [Parameter(Mandatory = $false)]
        [string]
        $Name,
        [Parameter(Mandatory = $false)]
        [string]
        $Informatie,
        [Parameter(Mandatory = $false)]
        [string]
        $InfoType,
        [Parameter(Mandatory = $false)]
        [Int32]
        $IsCount = 0
    )

    begin {
        Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Start Function"

        foreach ($PSBoundParameter in $PSBoundParameters.GetEnumerator()) {
            Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): [Parameter]: $($PSBoundParameter.Key) : [Value]: $($PSBoundParameter.Value)"
        }

        $retval = @{CheckSuccess = $false; Name = $Name; Informatie = @(); InfoType = $InfoType; Operator = $Operator}
        # SubResults = @();
        $newvalue = $IsCount + 1

        if ($Informatie) {
            $retval.Informatie += $Informatie
        }
        else {
            Write-Debug "Informatie has no value"
        }
    }

    process {
        $allchecks = @()
        if (-not $ColumnName) {
            #$retstring = ""
            #[array]$returnobj = @()

            if ($Operator -eq "and") {
                $testbool = $true
            }
            elseif ($Operator -eq "or") {
                $testbool = $false
            }

            foreach ($item in $Waarde) {
                $SplatParams = @{}
                $SplatParams = $item

                $currentcheck = Test-CompareValue @SplatParams -TableRow $TableRow -IsCount $newvalue
                #$retval.SubResults += , $currentcheck
                if ($currentcheck["CheckSuccess"]) {
                    [string[]] $infochecks = , $currentcheck.Informatie
                    foreach ($infocheck in $currentcheck.Informatie) {
                        $retval.Informatie += $infocheck
                    }
                    $allchecks += @{CurrentCheck = $currentcheck}
                    if ($Operator -eq "or") {
                        $testbool = $true
                    }
                }
                else {
                    if ($Operator -eq "and") {
                        $testbool = $false
                    }
                }
            }
            $retval.Checksuccess = $testbool
        }
        else {
            Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): ColumnName found"
            [bool]$hasValue = $false
            if (Get-Member -inputobject $TableRow -name $ColumnName -Membertype Properties) {
                if (($TableRow.PSObject.Properties | Where-Object {$_.Name -eq $ColumnName }).Value -eq "") {
                    $ColumnValue = ""
                }
                else {
                    $ColumnValue = $TableRow | Select-Object -ExpandProperty $ColumnName
                }
            }
            [Boolean]$isvalue = $false
            if (($Waarde.StartsWith('$global:')) -and ($Waarde -isnot [Array])) {
                $globalvar = Get-Variable -Name $waarde.split(':')[1] -Scope Global
                if ($globalvar.Value) {
                    $Waarde = $globalvar
                }
                else {
                    $Waarde = [string]::Empty
                }
            }
            $WaardeString = $Waarde | ConvertTo-Json

            if (($Operator -eq "IsEmpty") -or ($Operator -eq "NotIsEmpty")) {
                [Boolean]$CheckEmpty = [string]::IsNullOrEmpty($ColumnValue)
                If ($CheckEmpty) {
                    Write-Debug "$($ColumnName) equal ""$($WaardeString)"" = $($Operator)"
                    $isvalue = $Operator -eq "IsEmpty"
                    Write-Debug "$($ColumnName) equal ""$($WaardeString)"" = $($Operator) + $($isvalue)"
                }
                else {
                    Write-Debug "$($ColumnName) equal ""$($WaardeString)"" = $($Operator)"
                    $isvalue = $Operator -eq "NotIsEmpty"
                    Write-Debug "$($ColumnName) equal ""$($WaardeString)"" = $($Operator) + $($isvalue)"
                }
            }
            else {
                if ($ColumnValue) {
                    Switch ($Operator) {
                        "eq" {
                            Write-Debug "$($ColumnName) equal ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -eq $Waarde
                        }
                        "ne" {
                            Write-Debug "$($ColumnName) not equals ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -ne $Waarde
                        }
                        "ge" {
                            Write-Debug "$($ColumnName) greather than or equal ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -ge $Waarde
                        }
                        "gt" {
                            Write-Debug "$($ColumnName) greather than ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -gt $Waarde
                        }
                        "lt" {
                            Write-Debug "$($ColumnName) less than ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -lt $Waarde
                        }
                        "like" {
                            Write-Debug "$($ColumnName) like ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -like $Waarde
                        }
                        "notlike" {
                            Write-Debug "$($ColumnName) notlike ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -notlike $Waarde
                        }
                        "match" {
                            Write-Debug "$($ColumnName) match ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -match $Waarde
                        }
                        "notmatch" {
                            Write-Debug "$($ColumnName) notmatch ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -notmatch $Waarde
                        }
                        "contains" {
                            Write-Debug "$($ColumnName) contains ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -contains $Waarde
                        }
                        "notcontains" {
                            Write-Debug "$($ColumnName) notcontains ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -notcontains $Waarde
                        }
                        "in" {
                            Write-Debug "$($ColumnName) in ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -in $Waarde
                        }
                        "notin" {
                            Write-Debug "$($ColumnName) in ""$($ColumnValue)"" equals ""$($WaardeString)"""
                            $isvalue = $ColumnValue -notin $Waarde
                        }
                    }
                }
            }
            if ($isvalue) {

                $WaardeString = $Waarde | ConvertTo-Json
                Write-Debug -Message "$($WaardeString) = $($isvalue)"
                Write-Debug -Message "CheckSuccess = true"
                $retval.CheckSuccess = $true
            }
            else {
                Write-Debug -Message "CheckSuccess = false"
                $retval.CheckSuccess = $false
            }
        }
        return $retval
    }

    end {
        Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): End Function"
    }

}