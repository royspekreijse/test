﻿<#
#requires -version 4.0
#this requires the PowerShell ISE

Function New-ConditionalBreakPoint {
[cmdletbinding()]
Param(
[ValidateNotNullorEmpty()]
[string]$Variable = $psise.CurrentFile.Editor.SelectedText
)

 Add-Type -AssemblyName "microsoft.visualbasic" -ErrorAction Stop
 $Prompt =  "Enter an IF ( condition ) to force a break"
 $Title = "New Conditional Breakpoint"
 $Default = "`$$variable -SomeOperator SomeValue"
 $if = [microsoft.visualbasic.interaction]::InputBox($Prompt,$Title,$Default)

if ($if) {
    $action = [scriptblock]::Create( "If ($if) { Break}")
    Set-PSBreakpoint -Script $psise.CurrentFile.FullPath -Variable $Variable -Action $action
}
else {
    Write-Warning "No IF condition specified."
}
}
#end function

#add menu-shortcut
$psise.CurrentPowerShellTab.AddOnsMenu.Submenus.Add("New Conditional Breakpoint",{New-ConditionalBreakpoint},'Ctrl+E')
#>