<#
.SYNOPSIS
    Short description
.DESCRIPTION
    Long description
.EXAMPLE
    Example of how to use this cmdlet
.EXAMPLE
    Another example of how to use this cmdlet
#>
function Add-ColumnToTableRow {
    [CmdletBinding()]
    [OutputType([int])]
    param(
        [Parameter(Mandatory=$true)]
        [string]
        $TableName,
        [Parameter(Mandatory=$true)]
        [string]
        $RowId,
        [Parameter(Mandatory=$false)]
        [string]
        $PartitionKey,
        [Parameter(Mandatory=$true)]
        $StorageKey,
        [Parameter(Mandatory=$true)]
        $Ctx

    )

    begin {
    }

    process {
        
    }

    end {
    }
}