function New-TableStatistics {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [PSObject]$Machines,
        [Parameter(Mandatory = $true)]
        [PSObject]$MachineReport,
        [int16]$NumberOfPreviousDays = 7
    )

    #Set write-warning to better stand-out from verbose and debug info.
    $a = (Get-Host).PrivateData
    If ($a) {
        #Not every PS host has this capability
        $PreviousWarningBackgroundColor = $a.WarningBackgroundColor
        $PreviousWarningForegroundColor = $a.WarningForegroundColor
        $PreviousVerboseForegroundColor = $a.VerboseForegroundColor
        $a.WarningBackgroundColor = "red"
        $a.WarningForegroundColor = "white"
        $a.VerboseForegroundColor = 'cyan'
    }
    Write-Debug -Message "$(Get-Date -Format 'HH:mm:ss:fff'): $($MyInvocation.MyCommand.Name): Starting"

    $DateString = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd")
    $Header = "CloudSuite Reporting - TableStatistics created on $($DateString)"
    $Files = @()

    $Info = [String]::Empty



    #Machines
    $Info += "`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $Info += "Machines table`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $ActiveMachines = $Machines | Where-Object {$_.Status -eq 'Active'}
    $Info += "Machine table contains total of $($Machines.Count) machines`n"
    $IaaSMachines = $ActiveMachines | Where-Object {$_.SubscriptionID -ne '10000000-0000-0000-0000-000000000001' -or $_.SubscriptionID -ne $null -or $_.SubscriptionID -ne '' }
    $Info += "Machine table contains total of $($IaaSMachines.Count) active machines registered in an IaaS`n"
    $MultipleMAC = @()
    $Grouped = $ActiveMachines | Group-Object MAC
    foreach ($Group in $Grouped) {
        If ($Group.count -gt 1) {
            foreach ($Item in $Group.Group) {
                $MultipleMAC += $Item
            }
        }
        #$Result += $Group.Group[-1] #Just post last upload
    }
    If ($MultipleMAC) {
        $Info += "WARNING: Multiple MAC usage detected. $($Grouped.Count) MAC addresses shared amongst $($Grouped.Group.Count) active machines. Differences in some counts might occur`n"
        $FileName = "$($env:TEMP)\Machines-MultipleMAC.json"
        $MultipleMAC | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }
    $NoIaaSMachines = $ActiveMachines | Where-Object {$_.SubscriptionID -eq '10000000-0000-0000-0000-000000000001' -or $_.SubscriptionID -eq $null -or $_.SubscriptionID -eq '' }
    If ($NoIaaSMachines) {
        $Info += "WARNING: Machine table contains $($NoIaaSMachines.Count) active machine(s) which are not registered in any IaaS`n"
        $FileName = "$($env:TEMP)\Machines-NoIaaSMachines.json"
        $NoIaaSMachines | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }
    $WindowsMachines = $ActiveMachines | Where-Object vmOSType -eq "Windows"
    $Info += "Machine table contains total of $($WindowsMachines.Count) active Windows machines`n"
    $NoWindowsMachines = $ActiveMachines | Where-Object vmOSType -ne "Windows"
    If ($NoWindowsMachines) {
        $Info += "WARNING: Machine table contains $($NoWindowsMachines.Count) active machine(s) which are not Windows-based`n"
        $FileName = "$($env:TEMP)\Machines-NoWindowsMachines.json"
        $NoWindowsMachines | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }
    $Windows2008Machines = $ActiveMachines | Where-Object vmOSName -like "*2008*"
    $Info += "Machine table contains total of $($Windows2008Machines.Count) active Windows 2008 platform machines`n"

    #MachineReport general
    $Info += "`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $Info += "MachineReport table - general`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    For ($i = 0; $i -le $NumberOfPreviousDays; $i++) {
        $MachineReportDay = $MachineReport | Where-Object {$_.CreatedTimestamp -ge (Get-Date).AddDays( - $i).ToUniversalTime().ToString("yyyy-MM-ddT00:00:00.000Z") -and $_.CreatedTimestamp -lt (Get-Date).AddDays( - $i).ToUniversalTime().ToString("yyyy-MM-ddT23:59:59.999Z")}
        If ($MachineReportDay) {Break}

    }
    #Just get last result, if there have been multiple uploads (testing or other reason)
    $Result = @()
    $MultipleMAC = @()
    $Grouped = $MachineReportDay | Group-object MAC # Detect multiple uploads within timeframe
    foreach ($Group in $Grouped) {
        If ($Group.count -gt 1) {
            foreach ($Item in $Group.Group) {
                $MultipleMAC += $Item
            }
        }
        $Result += $Group.Group[-1] #Just post last upload
    }
    If ($MultipleMAC) {
        $Info += "WARNING: Multiple MAC usage detected. $($Grouped.Count) MAC addresses shared amongst $($Grouped.Group.Count) reported machines. Using only one sample. Differences in some counts might occur`n"
        $FileName = "$($env:TEMP)\MachineReport-MultipleMAC.json"
        $MultipleMAC | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }
    $MachineReportDay = $Result
    $Info += "Last MachineReport created on $((Get-Date).AddDays($InfoDay).ToUniversalTime().ToString(`"yyyy-MM-dd`"))`n"
    If ($MachineReportDay.Count -lt $IaaSMachines.Count) {
        $Info += "WARNING: Missing $($IaaSMachines.Count-$MachineReportDay.Count) active machines in MachineReport table from ITON IaaS`n"
        $CompareResult = Compare-Object $IaaSMachines $MachineReportDay -Property vmId
        $MachineReportMissingIaaSMachines = @()
        foreach ($Item in $CompareResult) {
            If ($Item.SideIndicator -eq '<=') {
                $MachineReportMissingIaaSMachines += $IaaSMachines |Where-Object -property vmId -eq $Item.vmId
            }
        }
        $FileName = "$($env:TEMP)\MachineReport-MissingIaaSMachines.json"
        $MachineReportMissingIaaSMachines | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }

    #MachineReport bruto values
    $Info += "`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $Info += "MachineReport table - bruto values`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $MachineReportBruto = @()
    For ($i = 0; $i -lt $NumberOfPreviousDays; $i++) {
        #Last day is defined as 'error' day; total count back is more then $NumberOfPreviousDays then
        $DateString = (Get-Date).AddDays( - $i).ToUniversalTime().ToString("yyyy-MM-dd")
        $MachineReportCurrent = $MachineReportDay| Where-Object {$_.IaaSMetricsDate -eq $DateString}
        If ($MachineReportCurrent) {
            $Info += "$($MachineReportCurrent.Count) machines reported bruto values, created on $($DateString)`n"
            $MachineReportBruto += $MachineReportCurrent
        }
    }
    If ($MachineReportBruto.Count -eq $MachineReportDay.Count) {
        $Info += "All machines reported bruto values`n"
    }
    Else {
        $MachineReportNoBrutoValues = @()
        #$CompareResult = Compare-Object $IaaSMachines $MachineReportDay -Property vmId
        #foreach ($Item in $CompareResult) {
        $Info += "WARNING: $($MachineReportDay.Count - $MachineReportBruto.Count) machines have no or older bruto values`n"
        Try {
            $CompareResult = Compare-Object $MachineReportBruto $MachineReportDay -Property vmId -ErrorAction Stop
            foreach ($Item in $CompareResult) {
                If ($Item.SideIndicator -eq '=>') {
                    $MachineReportNoBrutoValues += $IaaSMachines |Where-Object -property vmId -eq $Item.vmId
                }
            }
        }
        Catch {
            $MachineReportNoBrutoValues = $MachineReportDay
        }
        $FileName = "$($env:TEMP)\MachineReport-NoBrutoValues.json"
        $MachineReportNoBrutoValues | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
        #}
    }

    #MachineReport netto values
    $Info += "`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $Info += "MachineReport table - netto values`n"
    $Info += "---------------------------------------------------------------------------------------`n"
    $MachineReportWindows = @()
    Foreach ($WM in $WindowsMachines) {
        $MachineReportWindows += $MachineReportDay | Where-Object {$_.MAC -eq $WM.MAC -and $_.OSName -notlike "*2008*"}
    }
    $Info += "Analyzing netto values for $($MachineReportWindows.Count) Windows >= 2012 machines ...`n"

    $MachineReportNetto = @()
    For ($i = 0; $i -lt $NumberOfPreviousDays; $i++) {
        #Last day is defined as 'error' day; total count back is more then $NumberOfPreviousDays then
        $DateString = (Get-Date).AddDays( - $i).ToUniversalTime().ToString("yyyy-MM-dd")
        $MachineReportCurrent = $MachineReportWindows| Where-Object {$_.MachineMetricsDate -eq $DateString}
        $MachineReportCurrent = $MachineReportCurrent | Where-Object NettoOSSize -gt 0 # There must also be values!
        If ($MachineReportCurrent ) {
            $Info += "$($MachineReportCurrent.Count) machines reported netto values, created on $($DateString)`n"
            $MachineReportNetto += $MachineReportCurrent
        }
    }
    If ($MachineReportNetto.Count -eq $MachineReportWindows.Count) {
        $Info += "All machines reported netto values`n"
    }
    Else {
        $MachineReportNoNettoValues = @()
        $Info += "WARNING: $($MachineReportWindows.Count - $MachineReportNetto.Count) machines have no or older netto values`n"
        Try {
            $CompareResult = Compare-Object $MachineReportNetto $MachineReportWindows -Property vmId -ErrorAction Stop
            foreach ($Item in $CompareResult) {
                If ($Item.SideIndicator -eq '=>') {
                    $MachineReportNoNettoValues += $IaaSMachines |Where-Object -property vmId -eq $Item.vmId
                }
            }
        }
        Catch {
            $MachineReportNoNettoValues = $MachineReportWindows
        }
        $FileName = "$($env:TEMP)\MachineReport-NoNettoValues.json"
        $MachineReportNoNettoValues | Select-Object computername, vmName, MAC, vmId | ConvertTo-Json | Out-File $FileName -force
        $Files += $FileName
    }

    return [PSCustomObject] @{
        Header = $Header
        Info   = $Info
        Files  = $Files
    }

    If ($a) {
        $a.WarningBackgroundColor = $PreviousWarningBackgroundColor
        $a.WarningForegroundColor = $PreviousWarningForegroundColor
        $a.VerboseForegroundColor = $PreviousVerboseForegroundColor
    }
}